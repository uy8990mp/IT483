var$=function(id) {
    return document.getElementById(id);
};

var joinList = function() {
	var email = $("email").value;
	var email1 = $("email12").value;
	var isValid = true;
	
	if (email1 === "") { 
		$("email_error").firstChild.nodeValue = "This field is required.";
		isValid = false;
	} else { $("email_error").firstChild.nodeValue = ""; } 

	if (email !== email1) { 
		$("email1_error").firstChild.nodeValue = "This entry must equal first entry.";
		isValid = false;
	} else { $("email1_error").firstChild.nodeValue = ""; }     
        
	if ($("finame").value === "") {
		$("fname_error").firstChild.nodeValue = 
                        "This field is required.";
		isValid = false;
	} else { $("fname_error").firstChild.nodeValue = ""; }  
	
	if (isValid) {
		$("email_form").submit(); 
	}

window.onload = function() {
    $("join_list").onclick = joinList;
    $("email").focus();
}
;